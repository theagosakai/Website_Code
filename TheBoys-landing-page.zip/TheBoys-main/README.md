# TheBoys
Landing Page do The Boys
<br/>
Usando HTML e CSS apenas!
<br/>
<br/>
Visualização do projeto final:
<br/>
<br/>
![Thebosu](https://user-images.githubusercontent.com/97799788/184231439-9337704d-385d-48cf-bb3a-93eb1230b9fa.png)
