# social-tree
Projeto criado para ensinar pessoas o basico de html e css

![image](https://user-images.githubusercontent.com/82914908/158889110-65a56864-5730-4e05-bdee-40728cedc722.png)
