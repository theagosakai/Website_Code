<h1 align="center">
  HBO Max
</h1>

<p align="center">
  <img alt="" src=".github/preview.jpg" width="100%">
</p>

<p align="center">
  <a href="#-tecnologias">Tecnologias</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-projeto">Projeto</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#memo-licença">Licença</a>
</p>

<p align="center">
 <img  src="https://img.shields.io/static/v1?label=license&message=MIT&color=5822b4&labelColor=991eeb" alt="License">
  
  <img src="https://img.shields.io/github/forks/birobirobiro/live-twitch-hbo-max?label=forks&message=MIT&color=5822b4&labelColor=991eeb" alt="Forks">

  <img src="https://img.shields.io/github/stars/birobirobiro/live-twitch-hbo-max?label=stars&message=MIT&color=5822b4&labelColor=991eeb " alt="Stars">
</p>

<p align="center">
  <img alt="" src=".github/logo-plane.svg" width="10%">
</p>

<br>

<p align="center">
  <img alt="" src=".github/preview-desktop.png" width="100%">
</p>

## 🚀 Tecnologias

Esse projeto foi desenvolvido com as seguintes tecnologias:

- HTML
- [Tailwind CSS](https://tailwindcss.com/)

## 🚧 Projeto:

Em construção

## 🎨 Inspiração:

Figma: https://www.figma.com/file/2A51gQJCk5V6LxcIh2en0b/HBO-Max-Redesign-Web-App-(Community)

## :memo: Licença

Esse projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

---

Feito com ♥ by birobirobiro
