# Erro404
<br/>
<br/>
Projeto construído do zero usando HTML e CSS apenas!!!
<br/>
<br/>
Visualização do projeto concluído:
<br/>
<br/>
![erro404](https://user-images.githubusercontent.com/97799788/186438623-a90ae1f0-f3f2-4204-a435-e5376cb6935e.png)
